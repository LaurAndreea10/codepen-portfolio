CHRONOSCROLL × Baseline Voyage — Laura Andreea — 9 November 2026

RO: În CodePen lipește codepen.html în panoul HTML, style.css în CSS și script.js în JS. Fără preprocesoare sau dependențe. Setează limba documentului ro. Linkurile către fișierele downloads sunt pentru versiunea găzduită; în CodePen folosește butonul de export HTML disponibil în aplicație.
EN: Paste codepen.html in HTML, style.css in CSS and script.js in JS. No preprocessors or dependencies. Set document language to ro. Hosted download links are for the hosted edition; use the app HTML export button in CodePen.

Tags: cpc-animation-timeline, codepenchallenge

Created with AI assistance. CSS drives native animations; JS manages controls, local preferences, optional audio and feature-specific fallbacks. Content remains readable without JS. System reduced motion always wins. No analytics, accounts or external fonts. Dates are from the official CodePen starter. Browser support checks do not guarantee rendering correctness.

Portfolio card and bilingual case-study copy: see portfolio-entry.json. The public GitHub portfolio has not been changed by this package.
