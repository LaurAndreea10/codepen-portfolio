/* Baseline Voyage × CHRONOSCROLL v2 — 9 November 2026.
   Native animations are CSS-driven. JS owns preferences, explicit audio,
   feature-specific legacy fallbacks, learning tools and exports. */
(() => {
  'use strict';
  const root=document.documentElement, $=(s,c=document)=>c.querySelector(s), $$=(s,c=document)=>Array.from(c.querySelectorAll(s));
  root.classList.add('js');
  const store={get(k){try{return localStorage.getItem(k);}catch{return null;}},set(k,v){try{localStorage.setItem(k,v);}catch{}},remove(k){try{localStorage.removeItem(k);}catch{}}};
  const read=(k,f)=>{try{return JSON.parse(store.get(k))??f;}catch{return f;}};
  const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
  const number=(v,f,a,b)=>Number.isFinite(Number(v))?clamp(Number(v),a,b):f;
  const oneOf=(v,vals,f)=>vals.includes(v)?v:f;
  const supports=s=>{try{return Boolean(window.CSS&&CSS.supports(s));}catch{return false;}};
  const caps={scroll:supports('animation-timeline: scroll()'),view:supports('animation-timeline: view()'),range:supports('animation-range: entry 0% cover 35%'),scope:supports('timeline-scope: --a'),property:Boolean(window.CSS&&CSS.registerProperty),observer:'IntersectionObserver' in window};
  const systemMotion=matchMedia('(prefers-reduced-motion: reduce)');
  const defaults={theme:'dark',palette:'cosmic',mode:'full',intensity:1,text:1,volume:.15,motion:false,contrast:false,flat:false,particles:false,fallback:false,cinema:false};
  let prefs=validatePrefs(read('bv-prefs',{})),lang=oneOf(store.get('bv-lang'),['ro','en'],'ro');
  let native=false,scoped=false,lessMotion=false,observer=null,frame=0,ambient=null,audioContext=null,audioGain=null,currentChapter='blink';
  let stamps=read('bv-passport',[]);stamps=Array.isArray(stamps)?stamps.filter(x=>['blink','webkit','gecko','star'].includes(x)):[];
  const events=$$('.journey .event'),badges=$$('.badge'),scroller=$('.mini__scroller'),gauge=$('.gauge'),gallery=$('.gallery__viewport'),stage=$('.sandbox-stage'),sample=$('.sample');
  const tr=(ro,en)=>lang==='ro'?ro:en;
  function validatePrefs(p){if(!p||typeof p!=='object')p={};return {theme:oneOf(p.theme,['dark','light'],'dark'),palette:oneOf(p.palette,['cosmic','aurora','observatory','retro','paper','neon','mono'],'cosmic'),mode:oneOf(p.mode,['full','compact','learning','simple'],'full'),intensity:number(p.intensity,1,0,1),text:number(p.text,1,1,1.3),volume:number(p.volume,.15,0,1),...Object.fromEntries(['motion','contrast','flat','particles','fallback','cinema'].map(k=>[k,p[k]===true]))};}
  function announce(selector,message){$(selector).textContent=message;}
  function renderStatus(){
    const p=$('.support-pill'),you=$('.you-status');
    const mode=lessMotion?tr('Mișcare redusă · conținut complet','Reduced motion · complete content'):native?(scoped?tr('CSS nativ · cronologii active','Native CSS · timelines active'):tr('CSS nativ + fallback pentru scope','Native CSS + scope fallback')):tr('Fallback JavaScript · animații adaptate','JavaScript fallback · adapted animations');
    p.hidden=false;p.dataset.mode=native?'native':'fallback';p.textContent=(native?'✓ ':'↺ ')+mode;
    you.textContent=lessMotion?tr('Tot conținutul rămâne vizibil. Mișcarea este dezactivată; indicatorii numerici urmăresc derularea.','All content stays visible. Motion is disabled; numeric indicators follow scrolling.'):native?tr('Browserul recunoaște scroll(), view() și animation-range. CSS conduce efectele; funcțiile lipsă primesc fallback separat.','Your browser recognizes scroll(), view() and animation-range. CSS drives effects; missing features get separate fallbacks.'):prefs.fallback?tr('Simulare fallback activă. Dezactiveaz-o în Setări pentru a reveni la capabilitățile browserului.','Fallback simulation is active. Disable it in Settings to return to your browser capabilities.'):tr('Lipsește o funcție necesară. Progresul este sincronizat cu JavaScript; evenimentele folosesc IntersectionObserver când este disponibil.','A required feature is missing. JavaScript synchronizes progress; events use IntersectionObserver when available.');
    const names={scroll:'scroll()',view:'view()',range:'animation-range',scope:'timeline-scope',property:'@property / registerProperty',observer:'IntersectionObserver'};
    $('#support-grid').replaceChildren(...Object.entries(caps).map(([k,v])=>{const box=document.createElement('div');box.className='box';const name=document.createElement('code');name.textContent=names[k];const value=document.createElement('strong');value.textContent=v?tr('Disponibil ✓','Available ✓'):tr('Fallback ↺','Fallback ↺');box.append(name,value);return box;}));
  }
  function setLang(value){lang=oneOf(value,['ro','en'],'ro');root.lang=lang;store.set('bv-lang',lang);$('.lang-toggle').setAttribute('aria-label',tr('Schimbă în engleză','Switch to Romanian'));renderStatus();renderPassport();renderGuide();renderAudio();}
  function applyPrefs(save=true){
    root.dataset.theme=prefs.theme;root.dataset.palette=prefs.palette;root.dataset.mode=prefs.mode;
    lessMotion=prefs.motion||systemMotion.matches||prefs.mode==='simple'||prefs.intensity===0;
    root.classList.toggle('still',lessMotion);root.classList.toggle('high',prefs.contrast);root.classList.toggle('flat',prefs.flat);root.classList.toggle('no-particles',prefs.particles);
    root.style.setProperty('--intensity',prefs.intensity);root.style.setProperty('--font-scale',prefs.text);
    native=caps.scroll&&caps.view&&caps.range&&!prefs.fallback;scoped=native&&caps.scope;
    root.dataset.sda=native?'native':'fallback';root.dataset.scoped=scoped?'native':'fallback';root.dataset.cinema=String(prefs.cinema&&native&&!lessMotion);$('#cinema-toggle').setAttribute('aria-pressed',String(prefs.cinema));root.dataset.registered=caps.property?'native':'fallback';
    Object.keys(defaults).forEach(k=>{const input=$('#pref-'+k);if(!input)return;if(input.type==='checkbox')input.checked=prefs[k];else input.value=prefs[k];const out=$('#pref-'+k+'-value');if(out)out.textContent=prefs[k];});
    if(audioGain&&audioContext)audioGain.gain.setTargetAtTime(prefs.volume*.06,audioContext.currentTime,.1);
    if(save)store.set('bv-prefs',JSON.stringify(prefs));
    configureFallback();renderStatus();syncLab();scheduleUpdate();
  }
  function configureFallback(){
    if(observer)observer.disconnect();observer=null;
    events.forEach(e=>e.classList.add('is-in'));
    if(!native&&!lessMotion&&caps.observer){events.forEach(e=>e.classList.remove('is-in'));observer=new IntersectionObserver(entries=>entries.forEach(en=>{if(en.isIntersecting){en.target.classList.add('is-in');observer.unobserve(en.target);}}),{threshold:.15});events.forEach(e=>observer.observe(e));}
    const needsPage=!native||!scoped||!caps.property||lessMotion;
    removeEventListener('scroll',scheduleUpdate);if(needsPage)addEventListener('scroll',scheduleUpdate,{passive:true});
  }
  function scheduleUpdate(){if(!frame)frame=requestAnimationFrame(updateFallback);}
  function updateFallback(){
    frame=0;const max=root.scrollHeight-innerHeight,p=max>0?clamp(scrollY/max):0;
    if(!native||lessMotion||!caps.property){root.style.setProperty('--scroll',p.toFixed(4));$('.ring').style.setProperty('--p',p.toFixed(4));$('.ring').style.setProperty('--pct',Math.round(p*100));}
    if(!native||!caps.property){const r=$('.journey').getBoundingClientRect(),jp=clamp(-r.top/Math.max(1,r.height-innerHeight));root.style.setProperty('--jp',clamp(jp/.85).toFixed(4));const y=jp<.12?2023:jp<.5?2023+Math.round((jp-.12)/.38*2):jp<.8?2025+Math.round((jp-.5)/.3):2026;$('.year').style.setProperty('--year',y);}
    if(!scoped||lessMotion){events.slice(0,3).forEach((ev,i)=>badges[i]?.classList.toggle('is-lit',ev.getBoundingClientRect().top<innerHeight*.75));badges[3]?.classList.toggle('is-lit',events[2].getBoundingClientRect().top<innerHeight*.5);}
    syncGauge();syncCards();syncSample();
  }
  function syncGauge(){if(!scoped||!caps.property||lessMotion){const max=scroller.scrollHeight-scroller.clientHeight,g=max>0?clamp(scroller.scrollTop/max):0;gauge.style.setProperty('--g',g.toFixed(4));gauge.style.setProperty('--gp',Math.round(g*100));}}
  function syncCards(){if(!scoped||lessMotion){const max=gallery.scrollWidth-gallery.clientWidth;root.style.setProperty('--cards',(max>0?clamp(gallery.scrollLeft/max):0).toFixed(4));}}
  scroller.addEventListener('scroll',syncGauge,{passive:true});gallery.addEventListener('scroll',syncCards,{passive:true});stage.addEventListener('scroll',syncSample,{passive:true});addEventListener('resize',scheduleUpdate);
  if(systemMotion.addEventListener)systemMotion.addEventListener('change',()=>applyPrefs(false));else if(systemMotion.addListener)systemMotion.addListener(()=>applyPrefs(false));
  const labDefaults={type:'scroll',axis:'block',ease:'linear',start:0,end:100,move:60,turn:30,scale:.7,opacity:.15};
  let lab={...labDefaults};
  function validateLab(x){if(!x||typeof x!=='object')x={};const l={type:oneOf(x.type,['scroll','view','named'],'scroll'),axis:oneOf(x.axis,['block','inline'],'block'),ease:oneOf(x.ease,['linear','ease-in-out','ease-out'],'linear'),start:number(x.start,0,0,80),end:number(x.end,100,20,100),move:number(x.move,60,0,160),turn:number(x.turn,30,-180,180),scale:number(x.scale,.7,.3,1.5),opacity:number(x.opacity,.15,0,1)};l.end=Math.max(l.start+5,l.end);return l;}
  try{const shared=new URL(location.href).searchParams.get('lab');if(shared&&shared.length<2000)lab=validateLab(JSON.parse(shared));}catch{}
  function writeLabControls(){Object.entries(lab).forEach(([key,val])=>{const el=$('#lab-'+key);if(el)el.value=val;const out=$('#lab-'+key+'-value');if(out)out.textContent=val;});}
  function timelineValue(){return lab.type==='named'?'--sandbox':lab.type==='view'?`view(${lab.axis})`:`scroll(${lab.axis} nearest)`;}
  function syncLab(){
    if(!sample)return;stage.dataset.axis=lab.axis;sample.style.setProperty('--move',lab.move+'px');sample.style.setProperty('--turn',lab.turn+'deg');sample.style.setProperty('--zoom',lab.scale);sample.style.setProperty('--fade',lab.opacity);sample.style.setProperty('--ease',lab.ease);sample.style.setProperty('--sample-timeline',timelineValue());sample.style.setProperty('--sample-range',`${lab.start}% ${lab.end}%`);
    const fallback=!native||(lab.type==='named'&&!scoped);root.dataset.sampleFallback=fallback?'true':'false';
    if(!fallback){sample.style.removeProperty('transform');sample.style.removeProperty('opacity');}
    $('#live-css').textContent=`.sandbox { timeline-scope: --sandbox; }\n.sandbox-stage {\n  overflow: auto;\n  scroll-timeline: --sandbox ${lab.axis};\n}\n.sample {\n  animation: voyage ${lab.ease} both;\n  animation-timeline: ${timelineValue()};\n  animation-range: ${lab.start}% ${lab.end}%;\n}\n@keyframes voyage {\n  from {\n    opacity: ${lab.opacity};\n    transform: translate${lab.axis==='inline'?'X':'Y'}(${lab.move}px)\n      rotate(${lab.turn}deg) scale(${lab.scale});\n  }\n  to { opacity: 1; transform: none; }\n}`;
    syncSample();
  }
  function syncSample(){
    const inline=lab.axis==='inline',max=inline?stage.scrollWidth-stage.clientWidth:stage.scrollHeight-stage.clientHeight;
    let p=max>0?clamp((inline?stage.scrollLeft:stage.scrollTop)/max):0;
    if(!scoped||lessMotion)stage.parentElement.style.setProperty('--sandbox-progress',p.toFixed(4));
    if(native&&(lab.type!=='named'||scoped)||lessMotion)return;
    if(lab.type==='view'){const raw=(inline?stage.clientWidth-(sample.offsetLeft-stage.scrollLeft):stage.clientHeight-(sample.offsetTop-stage.scrollTop));p=clamp(raw/((inline?stage.clientWidth:stage.clientHeight)+(inline?sample.offsetWidth:sample.offsetHeight)));}
    p=clamp((p-lab.start/100)/Math.max(.01,(lab.end-lab.start)/100));if(lab.ease==='ease-in-out')p=p*p*(3-2*p);else if(lab.ease==='ease-out')p=1-Math.pow(1-p,3);
    sample.style.opacity=lab.opacity+(1-lab.opacity)*p;sample.style.transform=`translate${inline?'X':'Y'}(${lab.move*(1-p)}px) rotate(${lab.turn*(1-p)}deg) scale(${lab.scale+(1-lab.scale)*p})`;
  }
  Object.keys(labDefaults).forEach(key=>$('#lab-'+key).addEventListener('input',()=>{lab=validateLab(Object.fromEntries(Object.keys(labDefaults).map(k=>[k,$('#lab-'+k).value])));writeLabControls();syncLab();}));
  const behavior=()=>lessMotion?'instant':'smooth';
  $('#sample-start').onclick=()=>stage.scrollTo({top:0,left:0,behavior:behavior()});
  $('#sample-end').onclick=()=>stage.scrollTo({top:stage.scrollHeight,left:stage.scrollWidth,behavior:behavior()});
  $('#reset-lab').onclick=()=>{lab={...labDefaults};writeLabControls();syncLab();stage.scrollTo({top:0,left:0,behavior:'instant'});};
  function moveCards(dir){if(root.dataset.cinema==='true'){window.scrollBy({top:dir*innerHeight*.42,behavior:behavior()});}else gallery.scrollBy({left:dir*(Math.min(innerWidth*.78,360)+20),behavior:behavior()});}
  $('#cards-prev').onclick=()=>moveCards(-1);$('#cards-next').onclick=()=>moveCards(1);$('#cinema-toggle').onclick=()=>{prefs.cinema=!prefs.cinema;applyPrefs();};
  async function copy(text,target){try{if(!navigator.clipboard)throw Error();await navigator.clipboard.writeText(text);announce(target,tr('Copiat ✓','Copied ✓'));}catch{announce(target,tr('Copierea automată nu este disponibilă. Selectează textul de mai jos.','Automatic copying is unavailable. Select the text below.'));const area=document.createElement('textarea');area.value=text;area.readOnly=true;area.style.width='100%';area.rows=5;$(target).append(area);area.focus();area.select();}}
  $('#copy-css').onclick=()=>copy($('#live-css').textContent,'#lab-notice');
  $('#share-lab').onclick=()=>{const url=new URL(location.href);url.search='';url.searchParams.set('lab',JSON.stringify(lab));url.hash='playground';copy(url.href,'#lab-notice');};
  $('.lang-toggle').onclick=()=>setLang(lang==='ro'?'en':'ro');
  const settings=$('#settings-dialog'),guide=$('#guide-dialog');
  function showDialog(dialog){if(dialog.showModal)dialog.showModal();else{dialog.setAttribute('open','');dialog.setAttribute('role','dialog');}const focus=dialog.querySelector('button');focus?.focus();}
  function closeDialog(dialog){if(dialog.close)dialog.close();else dialog.removeAttribute('open');}
  $('#open-settings').onclick=()=>showDialog(settings);$('#close-settings').onclick=()=>closeDialog(settings);
  $('#quick-theme').onclick=()=>{prefs.theme=prefs.theme==='dark'?'light':'dark';applyPrefs();};
  Object.keys(defaults).forEach(key=>{const el=$('#pref-'+key);if(el)el.addEventListener('input',()=>{prefs[key]=el.type==='checkbox'?el.checked:el.value;prefs=validatePrefs(prefs);applyPrefs();});});
  $('#reset-prefs').onclick=()=>{prefs={...defaults};stopAudio();applyPrefs();announce('#settings-notice',tr('Preferințe resetate. Pașaportul este păstrat.','Preferences reset. Your passport is preserved.'));};
  [settings,guide].forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeDialog(d);}}));
  let guideStep=0;
  const guideSteps=[['↕','Tu controlezi timpul','You control time','Derulează normal. Bara și inelul urmăresc progresul; evenimentele apar la intrarea în cadru.','Scroll normally. The bar and ring follow progress; events reveal as they enter the viewport.'],['◎','Explorează cele trei motoare','Explore three engines','Alege o planetă sau parcurge cronologia. Fiecare capitol are un link direct și o ștampilă opțională.','Choose a planet or read the timeline. Each chapter has a direct link and an optional stamp.'],['--mini','Controlează de la distanță','Remote control','Derulează lista mică din laborator. Cadranul exterior urmărește cronologia ei, nu pagina.','Scroll the small list in the lab. The external gauge follows its timeline, not the page.'],['{ CSS }','Experimentează în laborator','Experiment in the lab','Schimbă axa, cronologia și keyframes. Copiază CSS-ul sau distribuie configurația prin link.','Change the axis, timeline and keyframes. Copy the CSS or share the configuration through a link.'],['◐','Alege confortul tău','Choose your comfort','Din Setări poți reduce mișcarea, opri 3D, schimba tema sau testa fallbackul. Sunetul este oprit inițial.','Settings let you reduce motion, disable 3D, change themes or test fallback mode. Sound starts off.']];
  function renderGuide(){const s=guideSteps[guideStep];$('#guide-step').textContent=`${guideStep+1} / ${guideSteps.length}`;$('#guide-visual').textContent=s[0];$('#guide-heading').textContent=lang==='ro'?s[1]:s[2];$('#guide-text').textContent=lang==='ro'?s[3]:s[4];$('#guide-prev').disabled=guideStep===0;$('#guide-next').textContent=guideStep===guideSteps.length-1?tr('Începe explorarea','Start exploring'):tr('Înainte','Next');}
  $('#open-guide').onclick=()=>{guideStep=0;renderGuide();showDialog(guide);};$('#close-guide').onclick=()=>{store.set('bv-guide','done');closeDialog(guide);};$('#guide-prev').onclick=()=>{guideStep=Math.max(0,guideStep-1);renderGuide();};$('#guide-next').onclick=()=>{if(guideStep===guideSteps.length-1){store.set('bv-guide','done');closeDialog(guide);}else{guideStep++;renderGuide();}};
  function renderPassport(){['blink','webkit','gecko'].forEach(id=>{const earned=stamps.includes(id);const stamp=$(`[data-earned=${id}]`);stamp.classList.toggle('earned',earned);$('.stamp-state',stamp).textContent=earned?tr('Colectată ✓','Collected ✓'):tr('De explorat','To explore');const button=$(`[data-stamp=${id}]`);button.disabled=earned;button.textContent=earned?tr('Ștampilă colectată ✓','Stamp collected ✓'):tr('Adaugă ștampila','Collect stamp');});const n=stamps.filter(x=>x!=='star').length;$('#passport-summary').textContent=`${n} / 3 · `+(n===3?tr('Explorator temporal ✓','Time explorer ✓'):tr('Călătoria continuă','The journey continues'))+(stamps.includes('star')?tr(' · Stea secretă ✧',' · Secret star ✧'):'');}
  function stamp(id){if(!stamps.includes(id)){stamps.push(id);store.set('bv-passport',JSON.stringify(stamps));renderPassport();chime();}}
  $$('[data-stamp]').forEach(b=>b.onclick=()=>stamp(b.dataset.stamp));
  $('#find-star').onclick=()=>{announce('#passport-notice',tr('Indiciu: o stea mică te așteaptă lângă planetele de la început.','Hint: a small star waits near the planets at the beginning.'));location.hash='home';};$('#secret-star').onclick=()=>{stamp('star');$('#secret-star').textContent='★';$('#secret-star').setAttribute('aria-label',tr('Stea descoperită','Star discovered'));};
  $('#clear-passport').onclick=()=>{stamps=[];store.remove('bv-passport');renderPassport();};
  $('#share-chapter').onclick=()=>{const url=new URL(location.href);url.search='';url.hash=currentChapter;copy(url.href,'#passport-notice');};
  if(caps.observer){const chapterObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){currentChapter=entry.target.id;store.set('bv-chapter',currentChapter);$$('.nav-map a').forEach(a=>a.removeAttribute('aria-current'));$('.nav-map a[href="#journey"]').setAttribute('aria-current','step');}}),{rootMargin:'-20% 0px -35% 0px',threshold:0});events.forEach(e=>chapterObserver.observe(e));}
  if(caps.observer){const sectionObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){$$('.nav-map a').forEach(a=>a.removeAttribute('aria-current'));const a=$('.nav-map a[href="#'+entry.target.id+'"]');if(a)a.setAttribute('aria-current','step');}}),{rootMargin:'-15% 0px -45% 0px',threshold:0});['journey','toolkit','lab','playground','learn','passport'].forEach(id=>sectionObserver.observe($('#'+id)));}
  const resume=oneOf(store.get('bv-chapter'),['blink','webkit','gecko','you'],null);if(resume){$('#resume').href='#'+resume;$('#resume').classList.add('show');}
  function renderAudio(){const b=$('#audio-toggle');b.textContent=ambient?tr('Oprește ambientul','Stop ambient'):tr('Pornește ambientul','Start ambient');b.setAttribute('aria-pressed',String(Boolean(ambient)));}
  function stopAudio(){if(ambient){ambient.forEach(o=>{try{o.stop();}catch{}});ambient=null;}if(audioContext){audioContext.close().catch(()=>{});audioContext=null;audioGain=null;}renderAudio();}
  async function startAudio(){try{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)throw Error();audioContext=new Audio();await audioContext.resume();audioGain=audioContext.createGain();audioGain.gain.value=prefs.volume*.06;audioGain.connect(audioContext.destination);ambient=[110,164.81].map(f=>{const o=audioContext.createOscillator();o.type='sine';o.frequency.value=f;o.connect(audioGain);o.start();return o;});renderAudio();}catch{stopAudio();announce('#settings-notice',tr('Audio indisponibil în acest browser.','Audio is unavailable in this browser.'));}}
  function chime(){if(!audioContext||!ambient)return;const o=audioContext.createOscillator(),g=audioContext.createGain(),now=audioContext.currentTime;o.frequency.setValueAtTime(440,now);o.frequency.exponentialRampToValueAtTime(660,now+.15);g.gain.setValueAtTime(prefs.volume*.06,now);g.gain.exponentialRampToValueAtTime(.0001,now+.3);o.connect(g);g.connect(audioContext.destination);o.start();o.stop(now+.3);}
  $('#audio-toggle').onclick=()=>ambient?stopAudio():startAudio();document.addEventListener('visibilitychange',()=>{if(audioContext){if(document.hidden)audioContext.suspend().catch(()=>{});else audioContext.resume().catch(()=>{});}});
  $('#copy-description').onclick=()=>copy(tr('CHRONOSCROLL × Baseline Voyage — creat pe 9 noiembrie 2026. O călătorie 3D prin istoria animation-timeline, cu scroll(), view(), cronologii denumite, laborator CSS, RO/EN, dark/light și fallback accesibil. Realizat cu asistență AI. #cpc-animation-timeline #codepenchallenge','CHRONOSCROLL × Baseline Voyage — created 9 November 2026. A 3D journey through animation-timeline history with scroll(), view(), named timelines, a CSS lab, RO/EN, dark/light and accessible fallback. Created with AI assistance. #cpc-animation-timeline #codepenchallenge'),'#export-notice');
  $('a[download][href$=".html"]').addEventListener('click',e=>{e.preventDefault();const clone=document.documentElement.cloneNode(true);clone.querySelectorAll('dialog[open]').forEach(d=>d.removeAttribute('open'));clone.classList.remove('js');const content='<!doctype html>\n'+clone.outerHTML;const blob=new Blob([content],{type:'text/html;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='baseline-voyage.html';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
  // The source package is hosted with the project; single-file and CodePen copies share that link.
  $('a[download][href$=".zip"]').href='https://laurandreea10.github.io/codepen-portfolio/baseline-voyage/downloads/Baseline-Voyage-CodePen.zip';
  writeLabControls();root.lang=lang;applyPrefs(false);setLang(lang);renderGuide();
  // First visit has a visible guide action; never trap visitors in an automatic modal.
})();
